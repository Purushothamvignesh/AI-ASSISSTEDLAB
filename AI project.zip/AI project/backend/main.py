"""Local-only Smart Banking learning demo. No real banking or payment services."""

from datetime import datetime, timezone
from pathlib import Path
import re
import sqlite3
from typing import Literal
from urllib.parse import parse_qs, urlparse

from fastapi import FastAPI, HTTPException
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import FileResponse
from pydantic import BaseModel, Field

BACKEND_DIR = Path(__file__).resolve().parent
PROJECT_DIR = BACKEND_DIR.parent
DATABASE_PATH = BACKEND_DIR / "smart_banking_demo.db"
HOMEPAGE_PATH = PROJECT_DIR / "homepage.html"
LOGINPAGE_PATH = PROJECT_DIR / "loginpage.html"
MPIN_PATH = PROJECT_DIR / "Mpin.html"

app = FastAPI(title="Smart Banking Demo API", version="1.0.0")
app.add_middleware(
    CORSMiddleware,
    allow_origin_regex=r"^https?://(localhost|127\.0\.0\.1)(:\d+)?$",
    allow_credentials=False,
    allow_methods=["GET", "POST", "PUT", "PATCH", "DELETE", "OPTIONS"],
    allow_headers=["Content-Type"],
)


def connect_db() -> sqlite3.Connection:
    connection = sqlite3.connect(DATABASE_PATH)
    connection.row_factory = sqlite3.Row
    return connection


def initialize_database() -> None:
    with connect_db() as connection:
        connection.execute(
            """CREATE TABLE IF NOT EXISTS transactions (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                created_at TEXT NOT NULL,
                description TEXT NOT NULL,
                amount REAL NOT NULL CHECK(amount > 0),
                channel TEXT NOT NULL,
                status TEXT NOT NULL DEFAULT 'Demo only'
            )"""
        )
        connection.execute(
            """CREATE TABLE IF NOT EXISTS customers (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                name TEXT NOT NULL,
                email TEXT NOT NULL DEFAULT '',
                phone TEXT NOT NULL DEFAULT '',
                created_at TEXT NOT NULL
            )"""
        )
        connection.execute(
            """CREATE TABLE IF NOT EXISTS loans (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                customer_id INTEGER NOT NULL,
                loan_type TEXT NOT NULL,
                amount REAL NOT NULL CHECK(amount > 0),
                term_months INTEGER NOT NULL,
                status TEXT NOT NULL DEFAULT 'Applied',
                created_at TEXT NOT NULL,
                FOREIGN KEY(customer_id) REFERENCES customers(id)
            )"""
        )
        customer_count = connection.execute("SELECT COUNT(*) FROM customers").fetchone()[0]
        if customer_count == 0:
            connection.execute(
                "INSERT INTO customers(name, email, phone, created_at) VALUES (?, ?, ?, ?)",
                ("Demo Customer", "customer@example.test", "0000000000", "2026-11-01"),
            )
        if connection.execute("SELECT COUNT(*) FROM transactions").fetchone()[0] == 0:
            samples = [
                ("2026-11-03", "Demo grocery purchase", 850.00, "UPI", "Sample"),
                ("2026-11-02", "Demo electricity bill", 1450.00, "Bill", "Sample"),
                ("2026-11-01", "Demo transfer received", 5000.00, "Transfer", "Sample"),
            ]
            connection.executemany(
                "INSERT INTO transactions(created_at, description, amount, channel, status) VALUES (?, ?, ?, ?, ?)",
                samples,
            )


initialize_database()


class TransferRequest(BaseModel):
    beneficiary: str = Field(min_length=2, max_length=80)
    beneficiary_id: str = Field(min_length=3, max_length=80)
    amount: float = Field(gt=0, le=100000)
    channel: Literal["Within Bank", "Other Bank", "UPI"]


class BillPaymentRequest(BaseModel):
    service: str = Field(min_length=2, max_length=50)
    consumer_id: str = Field(min_length=3, max_length=50)
    amount: float = Field(gt=0, le=50000)


class MpinRequest(BaseModel):
    mpin: str = Field(min_length=4, max_length=4)


class QRRequest(BaseModel):
    payload: str = Field(min_length=1, max_length=3000)


class CustomerRequest(BaseModel):
    name: str = Field(min_length=2, max_length=80)
    email: str = Field(default="", max_length=120)
    phone: str = Field(default="", max_length=20)


class LoanRequest(BaseModel):
    customer_id: int = Field(gt=0)
    loan_type: Literal["Personal", "Education", "Vehicle", "Home"]
    amount: float = Field(gt=0, le=10000000)
    term_months: int = Field(ge=1, le=360)


class LoanStatusUpdate(BaseModel):
    status: Literal["Applied", "Under Review", "Approved", "Rejected"]


@app.get("/", include_in_schema=False)
def homepage() -> FileResponse:
    if not HOMEPAGE_PATH.is_file():
        raise HTTPException(status_code=404, detail="homepage.html was not found")
    return FileResponse(HOMEPAGE_PATH)


@app.get("/api/health")
def health() -> dict[str, str]:
    return {"status": "ok", "mode": "demo"}


@app.get("/api/account")
def get_account() -> dict[str, object]:
    return {
        "account_type": "Savings",
        "masked_account": "XXXXXXX7730",
        "balance": 25000.00,
        "currency": "INR",
        "mode": "demo",
    }


@app.get("/api/profile")
def get_profile() -> dict[str, str]:
    return {
        "name": "PURUSHOTHAM VIGNESH",
        "email": "demo@example.test",
        "phone": "XXXXXX7730",
        "mode": "demo",
    }


@app.get("/api/customers")
def get_customers() -> dict[str, list[dict[str, object]]]:
    with connect_db() as connection:
        rows = connection.execute(
            "SELECT id, name, email, phone, created_at FROM customers ORDER BY id DESC"
        ).fetchall()
    return {"customers": [dict(row) for row in rows]}


@app.post("/api/customers", status_code=201)
def create_customer(request: CustomerRequest) -> dict[str, object]:
    name = request.name.strip()
    email = request.email.strip()
    phone = request.phone.strip()
    if not name:
        raise HTTPException(status_code=400, detail="Customer name is required.")
    created_at = datetime.now(timezone.utc).strftime("%Y-%m-%d")
    with connect_db() as connection:
        cursor = connection.execute(
            "INSERT INTO customers(name, email, phone, created_at) VALUES (?, ?, ?, ?)",
            (name, email, phone, created_at),
        )
        customer_id = int(cursor.lastrowid)
    return {"id": customer_id, "message": "Demo customer created.", "mode": "demo"}


@app.put("/api/customers/{customer_id}")
def update_customer(customer_id: int, request: CustomerRequest) -> dict[str, str]:
    name = request.name.strip()
    if not name:
        raise HTTPException(status_code=400, detail="Customer name is required.")
    with connect_db() as connection:
        cursor = connection.execute(
            "UPDATE customers SET name = ?, email = ?, phone = ? WHERE id = ?",
            (name, request.email.strip(), request.phone.strip(), customer_id),
        )
    if cursor.rowcount == 0:
        raise HTTPException(status_code=404, detail="Customer not found.")
    return {"message": "Demo customer updated.", "mode": "demo"}


@app.delete("/api/customers/{customer_id}")
def delete_customer(customer_id: int) -> dict[str, str]:
    with connect_db() as connection:
        has_loans = connection.execute(
            "SELECT 1 FROM loans WHERE customer_id = ? LIMIT 1", (customer_id,)
        ).fetchone()
        if has_loans:
            raise HTTPException(status_code=409, detail="Customer has demo loan records and cannot be deleted.")
        cursor = connection.execute("DELETE FROM customers WHERE id = ?", (customer_id,))
    if cursor.rowcount == 0:
        raise HTTPException(status_code=404, detail="Customer not found.")
    return {"message": "Demo customer deleted.", "mode": "demo"}


@app.get("/api/loans")
def get_loans() -> dict[str, list[dict[str, object]]]:
    with connect_db() as connection:
        rows = connection.execute(
            """SELECT loans.id, loans.customer_id, customers.name AS customer_name,
                      loans.loan_type, loans.amount, loans.term_months,
                      loans.status, loans.created_at
               FROM loans JOIN customers ON customers.id = loans.customer_id
               ORDER BY loans.id DESC"""
        ).fetchall()
    return {"loans": [dict(row) for row in rows]}


@app.post("/api/loans", status_code=201)
def create_loan(request: LoanRequest) -> dict[str, object]:
    with connect_db() as connection:
        customer = connection.execute(
            "SELECT id FROM customers WHERE id = ?", (request.customer_id,)
        ).fetchone()
        if customer is None:
            raise HTTPException(status_code=404, detail="Customer not found. Add the demo customer first.")
        cursor = connection.execute(
            "INSERT INTO loans(customer_id, loan_type, amount, term_months, status, created_at) "
            "VALUES (?, ?, ?, ?, 'Applied', ?)",
            (request.customer_id, request.loan_type, request.amount, request.term_months,
             datetime.now(timezone.utc).strftime("%Y-%m-%d")),
        )
        loan_id = int(cursor.lastrowid)
    return {"id": loan_id, "message": "Demo loan application recorded. This is not a credit decision.", "mode": "demo"}


@app.patch("/api/loans/{loan_id}/status")
def update_loan_status(loan_id: int, request: LoanStatusUpdate) -> dict[str, str]:
    with connect_db() as connection:
        cursor = connection.execute(
            "UPDATE loans SET status = ? WHERE id = ?", (request.status, loan_id)
        )
    if cursor.rowcount == 0:
        raise HTTPException(status_code=404, detail="Loan record not found.")
    return {"message": f"Demo loan status set to {request.status}.", "mode": "demo"}


@app.delete("/api/loans/{loan_id}")
def delete_loan(loan_id: int) -> dict[str, str]:
    with connect_db() as connection:
        cursor = connection.execute("DELETE FROM loans WHERE id = ?", (loan_id,))
    if cursor.rowcount == 0:
        raise HTTPException(status_code=404, detail="Loan record not found.")
    return {"message": "Demo loan application deleted.", "mode": "demo"}


@app.get("/api/transactions")
def get_transactions() -> dict[str, list[dict[str, object]]]:
    with connect_db() as connection:
        rows = connection.execute(
            "SELECT id, created_at, description, amount, channel, status "
            "FROM transactions ORDER BY id DESC LIMIT 50"
        ).fetchall()
    return {"transactions": [dict(row) for row in rows]}


def record_demo_transaction(description: str, amount: float, channel: str) -> int:
    created_at = datetime.now(timezone.utc).strftime("%Y-%m-%d")
    with connect_db() as connection:
        cursor = connection.execute(
            "INSERT INTO transactions(created_at, description, amount, channel, status) "
            "VALUES (?, ?, ?, ?, ?)",
            (created_at, description, amount, channel, "Demo only"),
        )
        return int(cursor.lastrowid)


@app.post("/api/transactions")
def create_demo_transfer(request: TransferRequest) -> dict[str, object]:
    beneficiary = request.beneficiary.strip()
    beneficiary_id = request.beneficiary_id.strip()
    if not beneficiary or not beneficiary_id:
        raise HTTPException(status_code=400, detail="Enter demo beneficiary details.")
    transaction_id = record_demo_transaction(
        f"Simulated {request.channel.lower()} transfer to {beneficiary}",
        request.amount,
        request.channel,
    )
    return {
        "id": transaction_id,
        "message": f"Demo transaction #{transaction_id} recorded. No money was transferred.",
        "mode": "demo",
    }


@app.post("/api/services/bill-payment")
def create_demo_bill(request: BillPaymentRequest) -> dict[str, object]:
    consumer_id = request.consumer_id.strip()
    if not consumer_id:
        raise HTTPException(status_code=400, detail="Enter a demo consumer ID.")
    transaction_id = record_demo_transaction(
        f"Simulated {request.service} entry for {consumer_id}",
        request.amount,
        "Bill",
    )
    return {
        "id": transaction_id,
        "message": f"Demo bill entry #{transaction_id} recorded. No bill was paid.",
        "mode": "demo",
    }


@app.post("/api/mpin")
def validate_demo_mpin(request: MpinRequest) -> dict[str, str]:
    # Deliberately validate format only. Never persist or log the supplied MPIN.
    if not re.fullmatch(r"\d{4}", request.mpin):
        raise HTTPException(status_code=400, detail="Demo MPIN must contain exactly 4 digits.")
    return {"message": "MPIN format accepted for demo. The MPIN was not stored.", "mode": "demo"}


@app.post("/api/qr/resolve")
def resolve_qr(request: QRRequest) -> dict[str, object]:
    raw_payload = request.payload.strip()
    if not raw_payload:
        raise HTTPException(status_code=400, detail="QR content is empty.")
    if raw_payload.lower().startswith("upi://"):
        parsed = urlparse(raw_payload)
        values = parse_qs(parsed.query)
        return {
            "type": "UPI QR content (read-only)",
            "details": {
                "payee": (values.get("pn") or [""])[0],
                "upi_id": (values.get("pa") or [""])[0],
                "amount": (values.get("am") or [""])[0],
            },
            "mode": "read-only",
        }
    # QR text is displayed as text only; URLs are never opened automatically.
    return {
        "type": "Text / URL / other QR (read-only)",
        "details": {"content": raw_payload[:500]},
        "mode": "read-only",
    }


@app.get("/homepage.html", include_in_schema=False)
def homepage_alias() -> FileResponse:
    if not HOMEPAGE_PATH.is_file():
        raise HTTPException(status_code=404, detail="homepage.html was not found")
    return FileResponse(HOMEPAGE_PATH)


@app.get("/loginpage.html", include_in_schema=False)
def login_page() -> FileResponse:
    if not LOGINPAGE_PATH.is_file():
        raise HTTPException(status_code=404, detail="loginpage.html was not found")
    return FileResponse(LOGINPAGE_PATH)


@app.get("/login", include_in_schema=False)
@app.get("/login.html", include_in_schema=False)
def login_alias() -> FileResponse:
    return login_page()


@app.get("/Mpin.html", include_in_schema=False)
def mpin_page() -> FileResponse:
    if not MPIN_PATH.is_file():
        raise HTTPException(status_code=404, detail="Mpin.html was not found")
    return FileResponse(MPIN_PATH)


@app.get("/create-mpin.html", include_in_schema=False)
def create_mpin_alias() -> FileResponse:
    return mpin_page()


@app.get("/home", include_in_schema=False)
@app.get("/home.html", include_in_schema=False)
def home_alias() -> FileResponse:
    return homepage_alias()
