# Smart Banking Demo

A local learning project that serves the existing `homepage.html` through FastAPI and stores sample transaction records in SQLite. This is not a real banking system: there is no bank connection, authentication, OTP service, UPI/payment gateway, or transfer of money. The MPIN endpoint validates format only and never stores the PIN. QR scanning is read-only and never opens links or initiates payment.

## Run on Windows

Open a VS Code terminal in the project folder, then:

```powershell
cd backend
py -m venv .venv
.venv\Scripts\Activate.ps1
py -m pip install -r requirements.txt
py -m uvicorn main:app --reload
```

If the `backend\.venv` environment already exists, activate it and continue from the package-install step. Open <http://127.0.0.1:8000> in Chrome or Edge. API documentation is at <http://127.0.0.1:8000/docs>.

## Demo API

- `GET /api/health`, `/api/account`, `/api/profile`, `/api/transactions`
- `GET`, `POST`, `PUT`, and `DELETE /api/customers` manage sample contact profiles
- `GET`, `POST`, `PATCH`, and `DELETE /api/loans` track demo applications and statuses
- `POST /api/transactions` records a simulated transfer
- `POST /api/services/bill-payment` records a simulated bill entry
- `POST /api/mpin` checks four-digit format without saving the PIN
- `POST /api/qr/resolve` parses QR text as read-only content

All account details and transactions are sample data. Do not enter real bank passwords, OTPs, MPINs, card details, or account credentials. The QR camera requires permission and a secure browser context; localhost is normally treated as secure. Browsers without `BarcodeDetector` use the jsQR fallback loaded from jsDelivr, so an internet connection is needed on the first scan. If camera access is blocked, choose a QR image in the scanner dialog instead.
